# Psilidios em Goiabeiras > 2024-04-11 2:44pm
https://universe.roboflow.com/mucosas/psilidios-em-goiabeiras

Provided by a Roboflow user
License: MIT

